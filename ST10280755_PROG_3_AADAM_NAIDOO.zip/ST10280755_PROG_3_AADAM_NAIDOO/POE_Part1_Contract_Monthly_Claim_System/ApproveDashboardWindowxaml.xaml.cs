﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace POE_Part1_Contract_Monthly_Claim_System
{
    public partial class ApproveDashboardWindow : Window
    {
        private string connectionString = @"Data Source=LAPTOP-LR4U8DK7\SQLEXPRESS01;Initial Catalog=ClaimSystemDB_2;Integrated Security=True;";

        public ApproveDashboardWindow()
        {
            InitializeComponent();
            LoadPendingClaims();
        }

        private void LoadPendingClaims()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Claims WHERE ClaimStatus = 'Pending'";
                SqlCommand cmd = new SqlCommand(query, con);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    lstPendingClaims.Items.Clear(); // Clear previous items

                    while (reader.Read())
                    {
                        lstPendingClaims.Items.Add("ClaimID: " + reader["ClaimID"] + " | Description: " + reader["ClaimDescription"]);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading claims: " + ex.Message);
                }
            }
        }

        private void Button_Click_Approve(object sender, RoutedEventArgs e)
        {
            if (lstPendingClaims.SelectedItem != null)
            {
                string selectedClaim = lstPendingClaims.SelectedItem.ToString();
                int claimId = int.Parse(selectedClaim.Split(' ')[1].Replace("ClaimID:", "").Trim());

                decimal claimAmount = GetClaimAmount(claimId);  // Fetch the claim amount based on claimId
                if (claimAmount > 0)  // Example validation
                {
                    UpdateClaimStatus(claimId, "Approved");
                    MessageBox.Show("Claim approved successfully!");
                }
                else
                {
                    MessageBox.Show("Claim amount is invalid.");
                }

                LoadPendingClaims(); // Refresh pending claims
            }
        }

        private void Button_Click_Reject(object sender, RoutedEventArgs e)
        {
            if (lstPendingClaims.SelectedItem != null)
            {
                string selectedClaim = lstPendingClaims.SelectedItem.ToString();
                int claimId = int.Parse(selectedClaim.Split(' ')[1].Replace("ClaimID:", "").Trim());

                UpdateClaimStatus(claimId, "Rejected");
                MessageBox.Show("Claim rejected.");
                LoadPendingClaims(); // Refresh pending claims
            }
        }

        private decimal GetClaimAmount(int claimId)
        {
            // Fetch claim amount from database based on claimId
            decimal claimAmount = 0;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT ClaimAmount FROM Claims WHERE ClaimID = @ClaimID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ClaimID", claimId);

                try
                {
                    con.Open();
                    claimAmount = (decimal)cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching claim amount: " + ex.Message);
                }
            }

            return claimAmount;
        }

        private void UpdateClaimStatus(int claimId, string status)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Claims SET ClaimStatus = @ClaimStatus WHERE ClaimID = @ClaimID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ClaimID", claimId);
                cmd.Parameters.AddWithValue("@ClaimStatus", status);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating claim status: " + ex.Message);
                }
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
