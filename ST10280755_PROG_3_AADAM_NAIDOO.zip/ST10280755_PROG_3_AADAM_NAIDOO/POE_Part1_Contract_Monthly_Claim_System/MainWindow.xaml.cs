﻿using System.Windows;

namespace POE_Part1_Contract_Monthly_Claim_System
{
    public partial class MainWindow : Window
    {
        private int _userId;

        // Constructor that accepts userId
        public MainWindow(int userId)
        {
            InitializeComponent();
            _userId = userId;  // Store the userId for later use
            // You can use _userId to load specific data or user information
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        // This method opens the StatusTrackerWindow with a string argument
        private void OpenStatusTrackerWindow()
        {
            StatusTrackerWindow statusTrackerWindow = new StatusTrackerWindow("Claim Tracker");
            statusTrackerWindow.Show();
        }

        // Button click event for submitting a claim
        private void Button_Click_SubmitClaim(object sender, RoutedEventArgs e)
        {
            // Add logic to handle claim submission (e.g., opening a form for claims)
            MessageBox.Show("Submit Claim button clicked.");
        }

        // Button click event to open the status tracker window
        private void Button_Click_StatusTracker(object sender, RoutedEventArgs e)
        {
            OpenStatusTrackerWindow();  // Opens StatusTrackerWindow
        }
    }
}
