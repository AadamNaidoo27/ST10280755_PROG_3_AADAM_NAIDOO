﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace POE_Part1_Contract_Monthly_Claim_System
{
    public partial class ClaimSubmissionWindow : Window
    {
        private string connectionString = @"Data Source=LAPTOP-LR4U8DK7\SQLEXPRESS01;Initial Catalog=ClaimSystemDB_2;Integrated Security=True;";
        private int userId;

        public ClaimSubmissionWindow(int userId)
        {
            InitializeComponent();
            this.userId = userId;
        }

        private void Button_Click_Submit(object sender, RoutedEventArgs e)
        {
            decimal hoursWorked, hourlyRate;

            // Validate hours worked and hourly rate input
            if (!decimal.TryParse(txtHoursWorked.Text, out hoursWorked) || hoursWorked <= 0)
            {
                MessageBox.Show("Please enter a valid number for hours worked.");
                return;
            }
            if (!decimal.TryParse(txtHourlyRate.Text, out hourlyRate) || hourlyRate <= 0)
            {
                MessageBox.Show("Please enter a valid number for hourly rate.");
                return;
            }

            decimal claimAmount = hoursWorked * hourlyRate;
            txtClaimAmount.Text = claimAmount.ToString();  // Display the calculated claim amount

            string description = txtDescription.Text;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Claims (UserID, ClaimDate, ClaimAmount, ClaimStatus, ClaimDescription) " +
                               "VALUES (@UserID, GETDATE(), @Amount, 'Pending', @Description)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserID", userId);
                cmd.Parameters.AddWithValue("@Amount", claimAmount);
                cmd.Parameters.AddWithValue("@Description", description);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Claim submitted successfully!");
                    this.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error submitting claim: " + ex.Message);
                }
            }
        }
    }
}
