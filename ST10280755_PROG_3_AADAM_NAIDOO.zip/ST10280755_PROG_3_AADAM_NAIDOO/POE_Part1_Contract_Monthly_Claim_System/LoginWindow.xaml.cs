﻿using System.Data.SqlClient;
using System.Windows;

namespace POE_Part1_Contract_Monthly_Claim_System
{
    public partial class LoginWindow : Window
    {
        private string connectionString = @"Data Source=LAPTOP-LR4U8DK7\SQLEXPRESS01;Initial Catalog=ClaimSystemDB_2;Integrated Security=True;";

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_Login(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, IsAdmin FROM Users WHERE Username = @Username AND Password = @Password";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        int userId = (int)reader["UserID"];
                        bool isAdmin = (bool)reader["IsAdmin"];

                        if (isAdmin)
                        {
                            new ApproveDashboardWindow().Show();
                        }
                        else
                        {
                            // Passing userId to MainWindow constructor
                            new MainWindow(userId).Show();
                        }

                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials. Please try again.");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Database connection error: " + ex.Message);
                }
            }
        }
    }
}
