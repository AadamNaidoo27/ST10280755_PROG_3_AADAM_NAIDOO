﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace POE_Part1_Contract_Monthly_Claim_System
{
    public partial class StatusTrackerWindow : Window
    {
        private string connectionString = @"Data Source=LAPTOP-LR4U8DK7\SQLEXPRESS01;Initial Catalog=ClaimSystemDB_2;Integrated Security=True;";

        // Constructor that accepts a string argument (to set the window title or pass other parameters)
        public StatusTrackerWindow(string windowTitle)
        {
            InitializeComponent();
            this.Title = windowTitle;  // Set the window title using the passed argument
            LoadClaimStatus();
            LoadStatusHistory();
        }

        // Default constructor (if needed)
        public StatusTrackerWindow()
        {
            InitializeComponent();
            LoadClaimStatus();
            LoadStatusHistory();
        }

        // Load claims status from database
        private void LoadClaimStatus()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT ClaimID, ClaimStatus FROM Claims";
                SqlCommand cmd = new SqlCommand(query, con);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    lstClaimStatus.Items.Clear(); // Clear previous items

                    while (reader.Read())
                    {
                        lstClaimStatus.Items.Add("ClaimID: " + reader["ClaimID"] + " | Status: " + reader["ClaimStatus"]);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading claim status: " + ex.Message);
                }
            }
        }

        // Load status history for claims from database
        private void LoadStatusHistory()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT ClaimID, StatusDescription, StatusDate FROM ClaimStatusHistory";
                SqlCommand cmd = new SqlCommand(query, con);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    lstStatusHistory.Items.Clear(); // Clear previous items

                    while (reader.Read())
                    {
                        lstStatusHistory.Items.Add("ClaimID: " + reader["ClaimID"] + " | Description: " + reader["StatusDescription"] + " | Date: " + reader["StatusDate"]);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading status history: " + ex.Message);
                }
            }
        }

        // Button click event handler for viewing status history
        private void Button_Click_ViewStatusHistory(object sender, RoutedEventArgs e)
        {
            if (lstClaimStatus.SelectedItem != null)
            {
                string selectedClaim = lstClaimStatus.SelectedItem.ToString();

                // Extract ClaimID from the string, remove "ClaimID:" and any surrounding spaces
                string claimIdStr = selectedClaim.Replace("ClaimID:", "").Trim();

                // Try to parse the ClaimID to an integer
                if (int.TryParse(claimIdStr, out int claimId))
                {
                    // Now load the status history for the selected claim
                    LoadClaimStatusHistory(claimId);
                }
                else
                {
                    MessageBox.Show("Invalid ClaimID format.");
                }
            }
            else
            {
                MessageBox.Show("Please select a claim to view its status history.");
            }
        }

        // Method to load status history based on the selected claim
        private void LoadClaimStatusHistory(int claimId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT StatusDescription, StatusDate FROM ClaimStatusHistory WHERE ClaimID = @ClaimID";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ClaimID", claimId);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    lstStatusHistory.Items.Clear(); // Clear previous items

                    while (reader.Read())
                    {
                        lstStatusHistory.Items.Add("Description: " + reader["StatusDescription"] + " | Date: " + reader["StatusDate"]);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading status history: " + ex.Message);
                }
            }
        }

        // Close button event handler
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}