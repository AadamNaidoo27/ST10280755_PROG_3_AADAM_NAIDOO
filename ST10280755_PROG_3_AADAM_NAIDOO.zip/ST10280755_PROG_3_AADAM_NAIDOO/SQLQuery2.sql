-- Step 1: Create the Database
CREATE DATABASE ClaimSystemDB_2;
GO

-- Step 2: Use the newly created database
USE ClaimSystemDB_2;
GO

-- Step 3: Create the Users table
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL, -- Increased the length for password storage
    Role NVARCHAR(20) NOT NULL -- For roles like 'Admin' or 'User'
);
GO

-- Step 4: Create the Claims table (with additional fields for Hours Worked and Hourly Rate)
CREATE TABLE Claims (
    ClaimID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NOT NULL FOREIGN KEY REFERENCES Users(UserID),
    ClaimDate DATETIME NOT NULL DEFAULT GETDATE(),
    ClaimAmount DECIMAL(18,2) NOT NULL,
    ClaimStatus NVARCHAR(50) NOT NULL, -- e.g. 'Pending', 'Approved', 'Rejected'
    ClaimDescription NVARCHAR(MAX) NOT NULL,
    HoursWorked DECIMAL(18,2) NOT NULL,  -- New field for Hours Worked
    HourlyRate DECIMAL(18,2) NOT NULL   -- New field for Hourly Rate
);
GO

-- Step 5: Create the ClaimStatusHistory table
CREATE TABLE ClaimStatusHistory (
    StatusID INT IDENTITY(1,1) PRIMARY KEY,
    ClaimID INT NOT NULL FOREIGN KEY REFERENCES Claims(ClaimID),
    StatusDate DATETIME NOT NULL DEFAULT GETDATE(),
    StatusDescription NVARCHAR(255) NOT NULL
);
GO

-- Step 6: Insert sample users (one admin and one regular user)
INSERT INTO Users (Username, Password, Role) VALUES
('admin', 'admin123', 'Admin'),
('user1', 'password123', 'User');
GO

-- Step 7: Insert sample claims for the users (now with HoursWorked and HourlyRate)
INSERT INTO Claims (UserID, ClaimAmount, ClaimStatus, ClaimDescription, HoursWorked, HourlyRate) VALUES
(1, 250.50, 'Pending', 'Monthly office supplies claim', 10, 25.05),
(2, 500.75, 'Approved', 'Travel reimbursement claim', 15, 33.38);
GO

-- Step 8: Insert sample claim status history data
INSERT INTO ClaimStatusHistory (ClaimID, StatusDescription, StatusDate) VALUES
(1, 'Claim submitted', '2024-10-01'),
(1, 'Claim under review', '2024-10-05'),
(2, 'Claim approved', '2024-10-03');
GO

-- Step 9: Select all claims with associated user information
SELECT c.ClaimID, u.Username, c.ClaimAmount, c.ClaimStatus, c.ClaimDescription, c.HoursWorked, c.HourlyRate, c.ClaimDate
FROM Claims c
JOIN Users u ON c.UserID = u.UserID;
GO

-- Step 10: Select claim status history for each claim
SELECT cs.ClaimID, cs.StatusDescription, cs.StatusDate, c.ClaimStatus
FROM ClaimStatusHistory cs
JOIN Claims c ON cs.ClaimID = c.ClaimID;
GO

-- Step 11: Drop ClaimStatusHistory table (if needed for cleanup)
DROP TABLE IF EXISTS ClaimStatusHistory;
GO

-- Step 12: Truncate the Claims table (for clearing data)
TRUNCATE TABLE Claims;
GO
